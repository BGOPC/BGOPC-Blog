from django.urls import path
from django.conf.urls.static import static
from django.conf import settings

from . import views

urlpatterns = [
    path('', views.login),
    # path('signup/', views.signup),
    path('signup/', views.SignupView.as_view()),
    # path('user/<uid>', views.page, name='profile-page'),
    path('user/<str:uid>', views.PageView.as_view(), name='profile-page'),
    path('upload/<unc>', views.NpView.as_view(), name='new-post'),
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
