# BGOPC Blog

This is an online weblog which will be hosted **Heroku**.
I made this in Python, Django web framework.
I'm using TailWind Css and Django-Tailwind Framework for design
